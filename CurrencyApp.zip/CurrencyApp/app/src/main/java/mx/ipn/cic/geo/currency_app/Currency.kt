package mx.ipn.cic.geo.currency_app

class Currency {
    var MXN: Double = 0.0 // Mexico
    var EUR: Double = 0.0 // Europa
    var GBP: Double = 0.0 // Reino unido
    var JPY: Double = 0.0 // Japon
    var CNY: Double = 0.0 // China
    var ARG: Double = 0.0 // Argentina
}