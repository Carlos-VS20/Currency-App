package mx.ipn.cic.geo.currency_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.gson.Gson
import mx.ipn.cic.geo.currency_app.databinding.ActivityMainBinding
import java.io.InputStreamReader
import java.net.URL
import javax.net.ssl.HttpsURLConnection

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Se coloca como comentario, cambio por usar viewbinding.
        // setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Invocar el método para equivalencia de monedas.
        getCurrencyData().start()
    }

    private fun getCurrencyData(): Thread
    {
        return Thread {
            val url = URL("https://open.er-api.com/v6/latest/usd")
            val connection = url.openConnection() as HttpsURLConnection

            Log.d("Resultado Petición: ", connection.responseCode.toString())

            if(connection.responseCode == 200) {
                val inputSystem = connection.inputStream
                val inputStreamReader = InputStreamReader(inputSystem, "UTF-8")
                val request = Gson().fromJson(inputStreamReader, Request::class.java)
                updateUI(request)
                inputStreamReader.close()
                inputSystem.close()
            }
            else {
                binding.textMonedaBase.hint = "PROBLEMA EN CONEXIÓN"
            }
        }
    }

    private fun updateUI(request: Request)
    {
        runOnUiThread {
            kotlin.run {
                binding.textUltimActualizacion.text = request.time_last_update_utc
                val conv_dig  = findViewById<EditText>(R.id.textMonedaConv)
                val button_Conv = findViewById<Button>(R.id.botonConvertir)
                var d_mxn:Float? = null
                var d_eur:Float? = null
                var d_gbp:Float? = null
                var d_jpy:Float? = null
                var d_cny:Float? = null
                var d_arg:Float? = null

                button_Conv.setOnClickListener {
                    if(conv_dig.text.isNotEmpty()){
                        d_mxn = conv_dig.text.toString().toFloat() * request.rates.MXN.toFloat()
                        binding.textMonedaMexico.text = String.format("MXN: %.4f", d_mxn)
                        d_eur = conv_dig.text.toString().toFloat() * request.rates.EUR.toFloat()
                        binding.textMonedaEuro.text = String.format("EUR: %.4f", d_eur)
                        d_gbp = conv_dig.text.toString().toFloat() * request.rates.GBP.toFloat()
                        binding.textMonedaLibra.text = String.format("GBP: %.4f", d_gbp)
                        d_jpy = conv_dig.text.toString().toFloat() * request.rates.JPY.toFloat()
                        binding.textMonedaJapon.text = String.format("JPY: %.4f", d_jpy)
                        d_cny = conv_dig.text.toString().toFloat() * request.rates.CNY.toFloat()
                        binding.textMonedaChina.text = String.format("CNY: %.4f", d_cny)
                        d_arg = conv_dig.text.toString().toFloat() * request.rates.ARG.toFloat()
                        binding.textMonedaArgentina.text = String.format("ARG: %.4f", d_arg)
                    }
                }
                binding.textMonedaMexico.text = String.format("MXN: %.4f", request.rates.MXN)
                binding.textMonedaEuro.text = String.format("EUR: %.4f", request.rates.EUR)
                binding.textMonedaLibra.text = String.format("GBP: %.4f", request.rates.GBP)
                binding.textMonedaJapon.text = String.format("JPY: %.4f", request.rates.JPY)
                binding.textMonedaChina.text = String.format("CNY: %.4f", request.rates.CNY)
                binding.textMonedaArgentina.text = String.format("ARG: %.4f", request.rates.ARG)
            }
        }
    }
}